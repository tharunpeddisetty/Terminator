# Terminator

## This package is used to perform multiple Linear Regression and Logistic Regression using gradient descent algorithm.

Additional help will be added after the deployment of the package
